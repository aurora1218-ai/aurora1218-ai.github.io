type ParticleMode = 'atmosphere' | 'galaxy';

interface StarParticle {
  horizontal: number;
  vertical: number;
  radius: number;
  opacity: number;
  phase: number;
  period: number;
  drift: number;
  sparkle: boolean;
  warm: boolean;
}

interface Firefly {
  horizontal: number;
  vertical: number;
  phase: number;
  period: number;
  radius: number;
}

interface Meteor {
  born: number;
  duration: number;
  horizontal: number;
  vertical: number;
  speed: number;
  slope: number;
  trail: number;
}

function makeGlow(color: string): HTMLCanvasElement {
  const canvas = document.createElement('canvas');
  canvas.width = 64;
  canvas.height = 64;
  const context = canvas.getContext('2d');
  if (!context) return canvas;
  const glow = context.createRadialGradient(32, 32, 0, 32, 32, 32);
  glow.addColorStop(0, `rgba(${color},.85)`);
  glow.addColorStop(.08, `rgba(${color},.45)`);
  glow.addColorStop(.28, `rgba(${color},.13)`);
  glow.addColorStop(1, `rgba(${color},0)`);
  context.fillStyle = glow;
  context.fillRect(0, 0, 64, 64);
  return canvas;
}

export function createStarParticles(host: HTMLElement, mode: ParticleMode): () => void {
  const canvas = document.createElement('canvas');
  const context = canvas.getContext('2d');
  if (!context) return () => undefined;
  canvas.setAttribute('aria-hidden', 'true');
  canvas.dataset.particleMode = mode;
  Object.assign(canvas.style, {
    position: 'absolute', inset: '0', width: '100%', height: '100%',
    display: 'block', pointerEvents: 'none',
  });
  host.append(canvas);

  const coldGlow = makeGlow('189,211,255');
  const warmGlow = makeGlow('255,215,155');
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const deviceMemory = (navigator as Navigator & { deviceMemory?: number }).deviceMemory;
  const limitedDevice = navigator.hardwareConcurrency <= 4 || (deviceMemory !== undefined && deviceMemory <= 4);
  let width = 1;
  let height = 1;
  let pixelRatio = 1;
  let compact = false;
  let stars: StarParticle[] = [];
  let fireflies: Firefly[] = [];
  let meteor: Meteor | undefined;
  let nextMeteor = 7;
  let elapsed = 0;
  let previousFrame = 0;
  let previousPaint = 0;
  let frame = 0;
  let resizeTimer = 0;
  let visible = true;
  let disposed = false;
  let randomState = mode === 'galaxy' ? 121819 : 101912;
  const random = (): number => {
    randomState = (randomState * 1664525 + 1013904223) >>> 0;
    return randomState / 4294967296;
  };

  const render = (time: number, animate: boolean): void => {
    context.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
    context.clearRect(0, 0, width, height);
    context.globalCompositeOperation = 'screen';

    for (const particle of stars) {
      const drift = time * particle.drift;
      const starX = ((particle.horizontal * width + drift) % (width + 8) + width + 8) % (width + 8) - 4;
      const starY = particle.vertical * height + Math.sin(time * .035 + particle.phase) * 2;
      const twinkle = .61 + Math.sin(time / particle.period + particle.phase) * .27
        + Math.sin(time / (particle.period * .43) + particle.phase * 2) * .12;
      const alpha = particle.opacity * twinkle;
      const glowSize = particle.radius * (particle.sparkle ? 19 : 11);
      context.globalAlpha = alpha * (particle.sparkle ? .7 : .42);
      context.drawImage(particle.warm ? warmGlow : coldGlow,
        starX - glowSize / 2, starY - glowSize / 2, glowSize, glowSize);
      context.globalAlpha = alpha;
      context.fillStyle = particle.warm ? '#fff1d9' : '#e2eaff';
      context.beginPath();
      context.arc(starX, starY, particle.radius, 0, Math.PI * 2);
      context.fill();
      if (particle.sparkle && twinkle > .67) {
        const rayLength = particle.radius * (2.4 + twinkle * 1.6);
        context.globalAlpha = alpha * .29;
        context.strokeStyle = '#dfebff';
        context.lineWidth = .55;
        context.beginPath();
        context.moveTo(starX - rayLength, starY);
        context.lineTo(starX + rayLength, starY);
        context.moveTo(starX, starY - rayLength * 1.2);
        context.lineTo(starX, starY + rayLength * 1.2);
        context.stroke();
      }
    }

    for (const particle of fireflies) {
      const flight = time / particle.period;
      const flyX = particle.horizontal * width + Math.sin(flight + particle.phase) * (compact ? 11 : 19);
      const flyY = particle.vertical * height + Math.sin(flight * .63 + particle.phase) * 12;
      const alpha = (.22 + Math.sin(flight * 1.4 + particle.phase) * .14) * .7;
      const size = particle.radius * 17;
      context.globalAlpha = alpha;
      context.drawImage(warmGlow, flyX - size / 2, flyY - size / 2, size, size);
      context.globalAlpha = alpha * 1.4;
      context.fillStyle = '#ffe1a2';
      context.beginPath();
      context.arc(flyX, flyY, particle.radius * .55, 0, Math.PI * 2);
      context.fill();
    }

    if (animate && !meteor && time >= nextMeteor) {
      meteor = {
        born: time, duration: 1.8 + random() * .6,
        horizontal: width * (.55 + random() * .4), vertical: height * (.04 + random() * .21),
        speed: (compact ? 155 : 250) + random() * 80, slope: .28 + random() * .22,
        trail: (compact ? 75 : 120) + random() * 55,
      };
    }
    if (meteor && animate) {
      const progress = (time - meteor.born) / meteor.duration;
      if (progress >= 1) {
        meteor = undefined;
        nextMeteor = time + (mode === 'galaxy' ? 12 : 17) + random() * 14;
      } else {
        const travel = (time - meteor.born) * meteor.speed;
        const headX = meteor.horizontal - travel;
        const headY = meteor.vertical + travel * meteor.slope;
        const tailX = headX + meteor.trail;
        const tailY = headY - meteor.trail * meteor.slope;
        const opacity = Math.sin(Math.PI * progress) ** 1.5 * .56;
        const trail = context.createLinearGradient(tailX, tailY, headX, headY);
        trail.addColorStop(0, 'rgba(174,203,255,0)');
        trail.addColorStop(.72, 'rgba(201,220,255,.35)');
        trail.addColorStop(1, 'rgba(240,245,255,.95)');
        context.globalAlpha = opacity;
        context.strokeStyle = trail;
        context.lineWidth = 1;
        context.beginPath();
        context.moveTo(tailX, tailY);
        context.lineTo(headX, headY);
        context.stroke();
        context.drawImage(coldGlow, headX - 9, headY - 9, 18, 18);
      }
    }
    context.globalAlpha = 1;
    context.globalCompositeOperation = 'source-over';
  };

  const animate = (timestamp: number): void => {
    frame = 0;
    if (disposed || !visible || document.hidden || reducedMotion.matches) return;
    if (!previousFrame) previousFrame = timestamp;
    const difference = timestamp - previousFrame;
    previousFrame = timestamp;
    elapsed += Math.min(difference, 100) / 1000;
    if (timestamp - previousPaint >= 1000 / 30) {
      previousPaint = timestamp - (timestamp - previousPaint) % (1000 / 30);
      render(elapsed, true);
    }
    frame = window.requestAnimationFrame(animate);
  };

  const synchronize = (): void => {
    if (frame) window.cancelAnimationFrame(frame);
    frame = 0;
    previousFrame = 0;
    previousPaint = 0;
    if (disposed) return;
    if (reducedMotion.matches) {
      meteor = undefined;
      render(elapsed, false);
    } else if (visible && !document.hidden) {
      frame = window.requestAnimationFrame(animate);
    }
  };

  const resize = (): void => {
    if (disposed) return;
    width = Math.max(1, host.clientWidth);
    height = Math.max(1, host.clientHeight);
    compact = width < 760 || limitedDevice;
    pixelRatio = Math.min(window.devicePixelRatio || 1, compact ? 1.25 : 1.5,
      Math.sqrt(2100000 / (width * height)));
    canvas.width = Math.round(width * pixelRatio);
    canvas.height = Math.round(height * pixelRatio);
    randomState = mode === 'galaxy' ? 121819 : 101912;
    const count = mode === 'galaxy' ? (compact ? 110 : 190) : (compact ? 100 : 220);
    stars = Array.from({ length: count }, (_, index) => {
      const horizontal = random();
      const vertical = mode === 'galaxy' ? random() : random() ** 1.3 * .81;
      const sparkle = index % 39 === 0;
      const protectedCenter = mode === 'atmosphere' && horizontal > .18 && horizontal < .7 && vertical > .25;
      return {
        horizontal, vertical, radius: sparkle ? .9 + random() * .35 : .25 + random() ** 2 * .7,
        opacity: (.24 + random() * .54) * (protectedCenter ? .52 : 1),
        phase: random() * Math.PI * 2, period: 2.5 + random() * 5,
        drift: (random() - .5) * (mode === 'galaxy' ? .28 : .48),
        sparkle, warm: index % 11 === 0,
      };
    });
    fireflies = mode === 'galaxy' ? [] : Array.from({ length: compact ? 5 : 9 }, () => ({
      horizontal: random(), vertical: .73 + random() * .24,
      phase: random() * Math.PI * 2, period: 5 + random() * 6, radius: .8 + random() * .7,
    }));
    meteor = undefined;
    nextMeteor = elapsed + 6 + random() * 5;
    render(elapsed, false);
    synchronize();
  };

  const resizeObserver = new ResizeObserver(() => {
    window.clearTimeout(resizeTimer);
    resizeTimer = window.setTimeout(resize, 100);
  });
  const intersectionObserver = new IntersectionObserver((entries) => {
    visible = entries.some((entry) => entry.isIntersecting);
    synchronize();
  }, { rootMargin: '60px' });
  resizeObserver.observe(host);
  intersectionObserver.observe(host);
  document.addEventListener('visibilitychange', synchronize);
  reducedMotion.addEventListener('change', synchronize);
  resize();

  return () => {
    disposed = true;
    window.cancelAnimationFrame(frame);
    window.clearTimeout(resizeTimer);
    resizeObserver.disconnect();
    intersectionObserver.disconnect();
    document.removeEventListener('visibilitychange', synchronize);
    reducedMotion.removeEventListener('change', synchronize);
    canvas.remove();
    stars = [];
    fireflies = [];
    coldGlow.width = 0;
    warmGlow.width = 0;
  };
}

export function createAtmosphere(host: HTMLElement): () => void {
  return createStarParticles(host, 'atmosphere');
}

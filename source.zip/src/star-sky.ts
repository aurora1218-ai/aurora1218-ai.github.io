export function createStarSky(host: HTMLElement): () => void {
  const canvas = document.createElement('canvas');
  const context = canvas.getContext('2d');
  if (!context) return () => undefined;
  canvas.setAttribute('aria-hidden', 'true');
  Object.assign(canvas.style, { width: '100%', height: '100%', display: 'block' });
  host.append(canvas);

  const paint = (): void => {
    const bounds = host.getBoundingClientRect();
    const scale = Math.min(1.3, 1900 / Math.max(bounds.width, bounds.height));
    const width = canvas.width = Math.max(1, Math.round(bounds.width * scale));
    const height = canvas.height = Math.max(1, Math.round(bounds.height * scale));
    const portrait = width < height;
    let state = 121819;
    const random = (): number => {
      state = (state * 1664525 + 1013904223) >>> 0;
      return state / 4294967296;
    };
    const sky = context.createLinearGradient(0, 0, width, height);
    sky.addColorStop(0, '#070d24');
    sky.addColorStop(.5, '#101c3d');
    sky.addColorStop(1, '#080d23');
    context.fillStyle = sky;
    context.fillRect(0, 0, width, height);

    const cloud = (centerX: number, centerY: number, radius: number, color: string, opacity: number, stretch: number): void => {
      context.save();
      context.translate(centerX, centerY);
      context.rotate(-.48);
      context.scale(stretch, 1);
      const gradient = context.createRadialGradient(0, 0, 0, 0, 0, radius);
      gradient.addColorStop(0, `rgba(${color},${opacity})`);
      gradient.addColorStop(.45, `rgba(${color},${opacity * .4})`);
      gradient.addColorStop(1, `rgba(${color},0)`);
      context.fillStyle = gradient;
      context.fillRect(-radius, -radius, radius * 2, radius * 2);
      context.restore();
    };

    context.globalCompositeOperation = 'screen';
    for (let index = 0; index < 31; index++) {
      const progress = index / 30;
      const centerX = width * (.23 + progress * .9);
      const centerY = height * (.78 - progress * .7);
      cloud(centerX, centerY, height * (.10 + random() * .10), index % 3 === 0 ? '142,116,175' : '93,129,177', .025 + random() * .052, 2.6);
    }
    for (let index = 0; index < 55; index++) {
      const progress = random();
      const spread = (random() - .5) * height * .21;
      cloud(width * (.29 + progress * .76), height * (.74 - progress * .66) + spread, height * (.012 + random() * .06), index % 4 === 0 ? '188,149,182' : '153,177,209', .025 + random() * .08, 1.9);
    }
    cloud(width * .74, height * .31, height * .11, '195,187,218', .12, 2.1);
    context.globalCompositeOperation = 'source-over';
    for (let index = 0; index < 17; index++) {
      const progress = index / 16;
      cloud(width * (.30 + progress * .72), height * (.725 - progress * .63), height * (.021 + random() * .025), '4,9,25', .14, 2.6);
    }

    const star = (starX: number, starY: number, radius: number, alpha: number, tint: string): void => {
      context.fillStyle = `rgba(${tint},${alpha})`;
      context.beginPath();
      context.arc(starX, starY, radius, 0, Math.PI * 2);
      context.fill();
    };
    const pixelScale = Math.max(.65, width / 1700);
    for (let index = 0; index < (portrait ? 1300 : 2300); index++) {
      star(random() * width, random() * height, (.15 + random() ** 4 * 1.1) * pixelScale, .08 + random() ** 2 * .57, index % 9 === 0 ? '239,206,177' : '201,218,245');
    }
    for (let index = 0; index < (portrait ? 1100 : 2100); index++) {
      const progress = random();
      const spread = (random() + random() + random() - 1.5) * height * .13;
      star(width * (.24 + progress * .87), height * (.78 - progress * .72) + spread, (.13 + random() * .55) * pixelScale, .08 + random() * .36, '211,218,239');
    }
    for (let index = 0; index < 17; index++) {
      const starX = width * (.04 + random() * .92);
      const starY = height * (.08 + random() * .82);
      const radius = (index % 4 === 0 ? 1.5 : 1) * pixelScale;
      cloud(starX, starY, radius * 10, '185,206,249', .25, 1);
      star(starX, starY, radius, .8, '236,238,252');
      if (index % 4 === 0) {
        context.strokeStyle = '#d9e6ff40';
        context.lineWidth = .55 * pixelScale;
        context.beginPath();
        context.moveTo(starX - radius * 4, starY);
        context.lineTo(starX + radius * 4, starY);
        context.moveTo(starX, starY - radius * 5);
        context.lineTo(starX, starY + radius * 5);
        context.stroke();
      }
    }
    const edge = context.createRadialGradient(width * .65, height * .40, height * .18, width * .55, height * .48, Math.max(width, height) * .8);
    edge.addColorStop(0, '#05081700');
    edge.addColorStop(1, '#050817b3');
    context.fillStyle = edge;
    context.fillRect(0, 0, width, height);
  };

  let timer = 0;
  const resize = (): void => {
    window.clearTimeout(timer);
    timer = window.setTimeout(paint, 120);
  };
  const observer = new ResizeObserver(resize);
  observer.observe(host);
  paint();
  return () => {
    observer.disconnect();
    window.clearTimeout(timer);
    canvas.remove();
  };
}

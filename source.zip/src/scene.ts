import * as THREE from 'three';

type Drawing = { background: HTMLCanvasElement; foreground: HTMLCanvasElement; poster: HTMLCanvasElement; horizon: number };
type Random = () => number;
type Point = { x: number; y: number };

const palette = {
  sky: '#14203f',
  lake: '#233d58',
  rose: '#f4c3d5',
  cream: '#fff0d6',
};

function seeded(seed: number): Random {
  let state = seed >>> 0;
  return () => {
    state = (state * 1664525 + 1013904223) >>> 0;
    return state / 4294967296;
  };
}

function makeCanvas(width: number, height: number): HTMLCanvasElement {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  return canvas;
}

function contextFor(canvas: HTMLCanvasElement): CanvasRenderingContext2D {
  const context = canvas.getContext('2d');
  if (!context) throw new Error('Canvas unavailable');
  return context;
}

function polygon(context: CanvasRenderingContext2D, points: number[][], fill: string | CanvasGradient): void {
  context.beginPath();
  points.forEach((point, index) => index === 0 ? context.moveTo(point[0], point[1]) : context.lineTo(point[0], point[1]));
  context.closePath();
  context.fillStyle = fill;
  context.fill();
}

function glow(context: CanvasRenderingContext2D, x: number, y: number, radius: number, color: string): void {
  const gradient = context.createRadialGradient(x, y, 0, x, y, radius);
  gradient.addColorStop(0, color);
  gradient.addColorStop(1, 'transparent');
  context.fillStyle = gradient;
  context.fillRect(x - radius, y - radius, radius * 2, radius * 2);
}

function ellipse(context: CanvasRenderingContext2D, x: number, y: number, radiusX: number, radiusY: number, fill: string, rotation = 0): void {
  context.beginPath();
  context.ellipse(x, y, radiusX, radiusY, rotation, 0, Math.PI * 2);
  context.fillStyle = fill;
  context.fill();
}

function ridge(context: CanvasRenderingContext2D, width: number, height: number, baseline: number, amplitude: number, seed: number, color: string): void {
  const random = seeded(seed);
  const points: Point[] = [];
  for (let index = -1; index <= 18; index++) {
    points.push({ x: width * index / 16, y: height * (baseline - random() * amplitude) });
  }
  context.beginPath();
  context.moveTo(-width * .1, height * .68);
  context.lineTo(points[0].x, points[0].y);
  for (let index = 1; index < points.length - 1; index++) {
    const next = points[index + 1];
    context.quadraticCurveTo(points[index].x, points[index].y, (points[index].x + next.x) / 2, (points[index].y + next.y) / 2);
  }
  context.lineTo(width * 1.1, height * .68);
  context.closePath();
  const gradient = context.createLinearGradient(0, height * (baseline - amplitude), 0, height * .62);
  gradient.addColorStop(0, color);
  gradient.addColorStop(1, '#77768f');
  context.fillStyle = gradient;
  context.fill();
}

function drawGalaxy(context: CanvasRenderingContext2D, width: number, height: number): void {
  const random = seeded(48021);
  const nebula = (centerX: number, centerY: number, radiusX: number, radiusY: number, color: string, rotation: number) => {
    context.save();
    context.translate(centerX, centerY);
    context.rotate(rotation);
    context.scale(1, radiusY / radiusX);
    glow(context, 0, 0, radiusX, color);
    context.restore();
  };
  nebula(width * .66, height * .09, width * .39, height * .12, '#8f83c017', -.12);
  nebula(width * .86, height * .035, width * .30, height * .075, '#789fca12', -.13);
  nebula(width * .46, height * .135, width * .23, height * .07, '#8c87ba0b', -.17);
  for (let index = 0; index < 10; index++) {
    const progress = index / 9;
    const centerX = width * (.28 + progress * .76);
    const centerY = height * (.137 - progress * .13 + Math.sin(progress * Math.PI * 2) * .012);
    nebula(centerX, centerY, width * (.07 + random() * .07), height * (.016 + random() * .026), index % 3 === 0 ? '#c2c9ef0f' : index % 3 === 1 ? '#a59bce11' : '#8ca8d211', -.14);
    if (index % 2 === 0) {
      nebula(centerX + width * .018, centerY + height * .009, width * .075, height * .013, '#121b391c', -.14);
    }
  }
  for (let index = 0; index < 325; index++) {
    const progress = random();
    const clusterX = width * (.25 + progress * .82);
    const clusterY = height * (.137 - progress * .13 + Math.sin(progress * Math.PI * 2) * .012);
    const distance = random() + random() + random() - 1.5;
    const starX = clusterX + (random() - .5) * width * .025;
    const starY = clusterY + distance * height * .036;
    if (starY < 0) continue;
    const starSize = width * (.00012 + random() * .00032);
    const alpha = .04 + random() * .21;
    ellipse(context, starX, starY, starSize, starSize, index % 4 === 0 ? `rgba(219,207,242,${alpha})` : `rgba(195,215,244,${alpha})`);
    if (index % 57 === 0) glow(context, starX, starY, width * .004, '#b8cef214');
  }
}

function drawSky(context: CanvasRenderingContext2D, width: number, height: number, portrait: boolean): { moonX: number; moonY: number; moonSize: number } {
  const random = seeded(3097);
  const sky = context.createLinearGradient(0, 0, 0, height * .66);
  sky.addColorStop(0, '#121b39');
  sky.addColorStop(.38, '#26365a');
  sky.addColorStop(.76, '#656482');
  sky.addColorStop(1, '#9b889b');
  context.fillStyle = sky;
  context.fillRect(0, 0, width, height);
  glow(context, width * .59, height * .38, width * .5, '#7a699126');
  glow(context, width * .15, height * .32, width * .35, '#4b6b9626');
  drawGalaxy(context, width, height);

  for (let index = 0; index < 215; index++) {
    const starX = random() * width;
    const starY = random() * height * .48;
    const starSize = (.32 + random() * .7) * width / 1500;
    const starAlpha = .14 + random() * .53;
    ellipse(context, starX, starY, starSize, starSize, `rgba(230,232,255,${starAlpha})`);
    if (index % 25 === 0) {
      glow(context, starX, starY, width * .006, '#dfe3ff25');
      context.strokeStyle = '#e3dcf44a';
      context.lineWidth = width / 2200;
      context.beginPath();
      context.moveTo(starX - starSize * 3.2, starY);
      context.lineTo(starX + starSize * 3.2, starY);
      context.moveTo(starX, starY - starSize * 3.2);
      context.lineTo(starX, starY + starSize * 3.2);
      context.stroke();
    }
  }

  context.save();
  for (let index = 0; index < 5; index++) {
    const cloudY = height * (.24 + index * .045);
    context.beginPath();
    context.moveTo(-width * .1, cloudY);
    context.bezierCurveTo(width * .2, cloudY - height * .035, width * .32, cloudY + height * .025, width * .56, cloudY - height * .008);
    context.bezierCurveTo(width * .73, cloudY - height * .03, width * .86, cloudY + height * .007, width * 1.1, cloudY - height * .03);
    context.strokeStyle = `rgba(185,171,202,${.016 + index * .004})`;
    context.lineWidth = height * (.009 + index * .004);
    context.stroke();
  }
  context.restore();

  const moonX = width * (portrait ? .71 : .592);
  const moonY = height * (portrait ? .217 : .218);
  const moonSize = Math.min(width, height) * (portrait ? .046 : .043);
  glow(context, moonX, moonY, moonSize * 5.6, '#f7d5e00a');
  glow(context, moonX, moonY, moonSize * 3.5, '#ffe2e812');
  glow(context, moonX, moonY, moonSize * 1.75, '#fff0dc32');
  const moon = context.createRadialGradient(moonX - moonSize * .4, moonY - moonSize * .4, 1, moonX, moonY, moonSize);
  moon.addColorStop(0, '#fff9e8');
  moon.addColorStop(.7, '#f7eddd');
  moon.addColorStop(1, '#ddd7d2');
  context.beginPath();
  context.arc(moonX, moonY, moonSize, 0, Math.PI * 2);
  context.fillStyle = moon;
  context.fill();
  context.save();
  context.beginPath();
  context.arc(moonX, moonY, moonSize * .95, 0, Math.PI * 2);
  context.clip();
  for (let index = 0; index < 30; index++) {
    ellipse(context, moonX + (random() - .5) * moonSize * 2, moonY + (random() - .5) * moonSize * 2, moonSize * (.06 + random() * .15), moonSize * (.04 + random() * .14), '#9d9bab0a');
  }
  context.restore();

  ridge(context, width, height, .50, .185, 7007, '#6c688a');
  ridge(context, width, height, .54, .14, 97, '#565b7a');
  ridge(context, width, height, .57, .105, 1239, '#414d6c');
  const haze = context.createLinearGradient(0, height * .43, 0, height * .59);
  haze.addColorStop(0, 'transparent');
  haze.addColorStop(.7, '#c9aec529');
  haze.addColorStop(1, '#b3a5c344');
  context.fillStyle = haze;
  context.fillRect(0, height * .43, width, height * .2);

  for (let index = 0; index < 7; index++) {
    const mistY = height * (.493 + index * .0085);
    const mist = context.createLinearGradient(0, 0, width, 0);
    mist.addColorStop(0, '#b2accc00');
    mist.addColorStop(.3, '#b2accc18');
    mist.addColorStop(.65, '#c6b3c227');
    mist.addColorStop(1, '#b2accc00');
    ellipse(context, width * .49, mistY, width * .64, height * .009, mist as unknown as string);
  }
  return { moonX, moonY, moonSize };
}

function drawWater(context: CanvasRenderingContext2D, sky: HTMLCanvasElement, width: number, height: number, horizon: number, moonX: number, portrait: boolean): void {
  const random = seeded(816);
  context.save();
  context.beginPath();
  context.rect(0, horizon, width, height - horizon);
  context.clip();
  const lake = context.createLinearGradient(0, horizon, 0, height);
  lake.addColorStop(0, '#898298');
  lake.addColorStop(.12, '#5a6a87');
  lake.addColorStop(.54, '#304b69');
  lake.addColorStop(1, '#152e49');
  context.fillStyle = lake;
  context.fillRect(0, horizon, width, height - horizon);
  context.save();
  context.translate(0, horizon * 2);
  context.scale(1, -1);
  context.globalAlpha = .36;
  context.drawImage(sky, 0, height * .31, width, height * .32, 0, height * .31, width, height * .32);
  context.restore();
  const depth = context.createLinearGradient(0, horizon, 0, height);
  depth.addColorStop(0, '#49628305');
  depth.addColorStop(.35, '#243e6530');
  depth.addColorStop(1, '#122e4ee8');
  context.fillStyle = depth;
  context.fillRect(0, horizon, width, height - horizon);

  context.save();
  const moonShaft = context.createLinearGradient(moonX - width * .16, 0, moonX + width * .16, 0);
  moonShaft.addColorStop(0, '#f6dbd300');
  moonShaft.addColorStop(.35, '#f6dbd307');
  moonShaft.addColorStop(.5, '#f6dbd314');
  moonShaft.addColorStop(.65, '#f6dbd307');
  moonShaft.addColorStop(1, '#f6dbd300');
  context.fillStyle = moonShaft;
  context.fillRect(moonX - width * .16, horizon, width * .32, height - horizon);
  glow(context, width * .79, height * .76, width * .19, '#f4b3cb15');
  glow(context, width * .8, height * .75, width * .09, '#f3bc6b12');
  context.restore();

  for (let index = 0; index < 340; index++) {
    const progress = random();
    const glintY = horizon + progress * (height - horizon);
    const spread = width * (.012 + progress * (portrait ? .14 : .095));
    const glintX = moonX + (random() + random() - 1) * spread;
    const glintWidth = width * (.001 + random() * .025) * (.3 + progress);
    const glintHeight = Math.max(.45, height * (.0003 + progress * .00075));
    ellipse(context, glintX, glintY, glintWidth, glintHeight, `rgba(242,221,218,${(.06 + random() * .23) * (1 - progress * .6)})`);
  }

  for (let index = 0; index < 250; index++) {
    const waterX = random() * width;
    const waterY = horizon + random() * (height - horizon);
    const waterProgress = (waterY - horizon) / (height - horizon);
    context.strokeStyle = index % 3 === 0 ? '#c0b7ca12' : '#1027461c';
    context.lineWidth = height * (.0004 + waterProgress * .0009);
    context.beginPath();
    context.moveTo(waterX, waterY);
    context.bezierCurveTo(waterX + width * .008, waterY - height * .001, waterX + width * .022, waterY + height * .001, waterX + width * (.01 + waterProgress * .035), waterY);
    context.stroke();
  }

  for (let index = 0; index < 95; index++) {
    const reflectionY = height * (.665 + random() * .24);
    const reflectionX = width * (.792 + (random() - .5) * (.022 + (reflectionY / height - .66) * .24));
    ellipse(context, reflectionX, reflectionY, width * (.001 + random() * .012), height * .0008, `rgba(244,180,112,${random() * .19})`);
  }
  context.restore();
}

function drawShore(context: CanvasRenderingContext2D, width: number, height: number, portrait: boolean): void {
  const random = seeded(2021);
  const shoreTop = portrait ? .67 : .645;
  context.save();
  context.beginPath();
  context.moveTo(width * 1.05, height * .548);
  context.bezierCurveTo(width * .95, height * .57, width * .89, height * .61, width * .81, height * shoreTop);
  context.bezierCurveTo(width * .7, height * .69, width * .715, height * .72, width * .79, height * .753);
  context.bezierCurveTo(width * .87, height * .80, width * .88, height * .92, width * .94, height * 1.03);
  context.lineTo(width * 1.1, height * 1.1);
  context.closePath();
  const grass = context.createLinearGradient(width * .8, height * .6, width, height);
  grass.addColorStop(0, '#364a57');
  grass.addColorStop(.38, '#293d46');
  grass.addColorStop(1, '#142c3b');
  context.fillStyle = grass;
  context.fill();
  context.save();
  context.clip();
  glow(context, width * .805, height * .695, width * .13, '#efbc6542');
  for (let index = 0; index < 1200; index++) {
    const grassX = width * (.70 + random() * .36);
    const grassY = height * (.61 + random() * .43);
    const grassLength = height * (.003 + random() * .012);
    context.strokeStyle = ['#71756937', '#87977c26', '#c1b2a21f', '#162b3a66'][index % 4];
    context.lineWidth = width / 2200;
    context.beginPath();
    context.moveTo(grassX, grassY);
    context.quadraticCurveTo(grassX + width * .0015, grassY - grassLength * .6, grassX + width * .004, grassY - grassLength);
    context.stroke();
  }
  for (let index = 0; index < 135; index++) {
    const petalX = width * (.72 + random() * .3);
    const petalY = height * (.63 + random() * .29);
    ellipse(context, petalX, petalY, width * .0016, height * .001, ['#e5adc58c', '#f7c7d5a1', '#c989b77a'][index % 3], random() * 3);
  }
  context.restore();

  const stonePoints = [[.765, .713, .026, .011], [.749, .694, .018, .01], [.804, .759, .027, .016], [.834, .782, .018, .012], [.909, .94, .035, .016]];
  stonePoints.forEach(([stoneX, stoneY, stoneWidth, stoneHeight], index) => {
    const stone = context.createLinearGradient(0, height * (stoneY - stoneHeight), 0, height * (stoneY + stoneHeight));
    stone.addColorStop(0, index % 2 === 0 ? '#6a7482' : '#647080');
    stone.addColorStop(.35, '#475568');
    stone.addColorStop(1, '#26394e');
    ellipse(context, width * stoneX, height * stoneY, width * stoneWidth, height * stoneHeight, stone as unknown as string, -.1);
    ellipse(context, width * (stoneX - .004), height * (stoneY - stoneHeight * .5), width * stoneWidth * .55, height * stoneHeight * .12, '#b7b2bb32', -.07);
  });
  context.restore();
}

function drawCottage(context: CanvasRenderingContext2D, width: number, height: number, portrait: boolean): void {
  const random = seeded(124);
  const houseScale = Math.min(width / (portrait ? 860 : 1500), height / 870);
  const houseX = width * (portrait ? .77 : .806);
  const houseY = height * (portrait ? .715 : .695);
  context.save();
  context.translate(houseX, houseY);
  context.scale(houseScale, houseScale);
  glow(context, -5, -60, 220, '#ecc28b12');
  ellipse(context, 10, 12, 173, 22, '#102b3a6b');
  polygon(context, [[-126, 8], [78, 8], [153, -26], [150, -41], [-129, -14]], '#63727a');
  polygon(context, [[-129, -14], [76, -14], [151, -45], [-48, -42]], '#9a9a967a');
  polygon(context, [[-111, -16], [76, -16], [76, -113], [-111, -113]], '#8f8391');
  polygon(context, [[76, -16], [145, -45], [145, -137], [76, -111]], '#685f78');
  const wallLight = context.createLinearGradient(-111, 0, 76, -120);
  wallLight.addColorStop(0, '#b7a0a184');
  wallLight.addColorStop(1, '#b7a0a100');
  context.fillStyle = wallLight;
  context.fillRect(-110, -112, 186, 96);
  polygon(context, [[-114, -112], [-16, -205], [83, -112]], '#9a8796');
  polygon(context, [[-16, -205], [66, -233], [162, -135], [83, -112]], '#544c67');

  context.strokeStyle = '#493e52';
  context.lineWidth = 6;
  [[-109, -111, 76, -111], [-109, -111, -109, -18], [75, -110, 75, -17], [-112, -18, 77, -18], [-16, -203, -16, -112], [-85, -134, 58, -134]].forEach(([startX, startY, endX, endY]) => {
    context.beginPath();
    context.moveTo(startX, startY);
    context.lineTo(endX, endY);
    context.stroke();
  });
  polygon(context, [[-141, -108], [-17, -226], [-8, -214], [-124, -100]], '#55516e');
  const roof = context.createLinearGradient(20, -220, 118, -100);
  roof.addColorStop(0, '#80758f');
  roof.addColorStop(.4, '#655e7d');
  roof.addColorStop(1, '#3f405e');
  polygon(context, [[-17, -226], [66, -253], [181, -132], [91, -102]], roof);
  context.save();
  context.beginPath();
  context.moveTo(-17, -226);
  context.lineTo(66, -253);
  context.lineTo(181, -132);
  context.lineTo(91, -102);
  context.clip();
  for (let index = 0; index < 11; index++) {
    context.beginPath();
    context.moveTo(-25 + index * 10, -237 + index * 11);
    context.lineTo(81 + index * 10, -272 + index * 11);
    context.strokeStyle = index % 2 === 0 ? '#b2a3b35e' : '#242b472e';
    context.lineWidth = index % 2 === 0 ? 2 : 4;
    context.stroke();
  }
  for (let index = 0; index < 7; index++) {
    context.beginPath();
    context.moveTo(-10 + index * 15, -238);
    context.lineTo(130 + index * 15, -94);
    context.strokeStyle = '#242b474d';
    context.lineWidth = 1.4;
    context.stroke();
  }
  for (let index = 0; index < 85; index++) {
    ellipse(context, random() * 210 - 20, random() * 155 - 250, 2 + random() * 3, 1 + random() * 1.5, ['#e2aac3ad', '#ffcddd9c', '#a87c9e80'][index % 3], random() * 2);
  }
  context.restore();
  context.strokeStyle = '#a59ab588';
  context.lineWidth = 2;
  context.beginPath();
  context.moveTo(-141, -108);
  context.lineTo(-17, -226);
  context.lineTo(66, -253);
  context.stroke();
  polygon(context, [[90, -107], [183, -138], [181, -128], [91, -96]], '#33364f');
  polygon(context, [[-141, -108], [-124, -102], [-15, -207], [-18, -221]], '#8d7a92');

  const windowGlow = context.createLinearGradient(0, -100, 0, -20);
  windowGlow.addColorStop(0, '#f9d5a0');
  windowGlow.addColorStop(.5, '#ffe3a8');
  windowGlow.addColorStop(1, '#d79769');
  glow(context, -68, -62, 75, '#ffd18531');
  glow(context, 18, -64, 70, '#ffcf7b2c');
  context.fillStyle = '#4e3d4a';
  context.fillRect(-100, -94, 62, 67);
  context.fillStyle = windowGlow;
  context.fillRect(-94, -88, 50, 55);
  context.fillStyle = '#fff2d132';
  context.fillRect(-90, -85, 12, 47);
  context.fillRect(-59, -85, 12, 47);
  context.strokeStyle = '#816052';
  context.lineWidth = 3;
  context.beginPath();
  context.moveTo(-69, -90);
  context.lineTo(-69, -31);
  context.moveTo(-96, -61);
  context.lineTo(-42, -61);
  context.stroke();
  context.fillStyle = '#493b4b';
  context.fillRect(-21, -94, 52, 79);
  context.fillStyle = windowGlow;
  context.fillRect(-15, -88, 40, 66);
  context.fillStyle = '#98705b';
  context.fillRect(3, -87, 3, 64);
  context.fillRect(-15, -54, 40, 3);
  context.fillRect(-15, -24, 40, 5);
  ellipse(context, 17, -42, 1.8, 1.8, '#fff1bc');
  polygon(context, [[93, -94], [128, -109], [128, -65], [93, -51]], '#ffd797');
  context.strokeStyle = '#6d5260';
  context.lineWidth = 4;
  context.beginPath();
  context.moveTo(110, -100);
  context.lineTo(110, -59);
  context.moveTo(93, -73);
  context.lineTo(128, -87);
  context.stroke();
  glow(context, -15, -153, 31, '#ffcf8128');
  ellipse(context, -15, -153, 16, 16, '#4b3e55');
  ellipse(context, -15, -153, 12, 12, '#eac495');
  context.strokeStyle = '#846052';
  context.lineWidth = 2;
  context.beginPath();
  context.moveTo(-15, -166);
  context.lineTo(-15, -141);
  context.moveTo(-27, -153);
  context.lineTo(-3, -153);
  context.stroke();

  polygon(context, [[-31, -14], [43, -14], [48, -5], [-37, -5]], '#9f9690');
  polygon(context, [[-37, -5], [48, -5], [54, 4], [-44, 4]], '#777e82');
  context.fillStyle = '#635066';
  context.fillRect(-129, -39, 22, 25);
  context.fillRect(44, -35, 22, 21);
  for (let index = 0; index < 23; index++) {
    const flowerX = (index < 12 ? -119 : 55) + (random() - .5) * 25;
    const flowerY = -41 - random() * 10;
    ellipse(context, flowerX, flowerY, 3 + random() * 2, 2.5, ['#f3bfd6', '#c8b1dd', '#edc796'][index % 3]);
  }
  context.restore();
}

function branch(context: CanvasRenderingContext2D, points: number[], width: number, color: string): void {
  context.beginPath();
  context.moveTo(points[0], points[1]);
  context.bezierCurveTo(points[2], points[3], points[4], points[5], points[6], points[7]);
  context.strokeStyle = color;
  context.lineWidth = width;
  context.lineCap = 'round';
  context.stroke();
}

function drawBlossomTree(context: CanvasRenderingContext2D, width: number, height: number, portrait: boolean, left = false): void {
  const random = seeded(left ? 9087 : 1578);
  context.save();
  if (left) {
    context.translate(width * -.055, height * -.028);
    context.scale(-.59, .66);
    context.translate(-width, 0);
    context.globalAlpha = .74;
  }
  const trunkX = width * (portrait ? 1.025 : .982);
  const trunkY = height * .89;
  const crownY = portrait ? .395 : .30;
  const localY = (amount: number) => height * (amount + (portrait ? .077 : 0));
  const trunkWidth = width * (portrait ? .023 : .017);
  branch(context, [trunkX, trunkY, width * .924, height * .73, width * .951, localY(.49), width * .854, localY(.32)], trunkWidth, '#2b3044');
  branch(context, [trunkX - width * .002, trunkY, width * .931, height * .70, width * .944, localY(.49), width * .853, localY(.32)], trunkWidth * .45, '#5b4a5b');
  branch(context, [width * .94, localY(.58), width * .91, localY(.43), width * .745, localY(.39), width * .69, localY(.27)], trunkWidth * .52, '#353347');
  branch(context, [width * .921, localY(.48), width * .98, localY(.37), width * 1.06, localY(.37), width * 1.05, localY(.24)], trunkWidth * .49, '#353347');
  branch(context, [width * .89, localY(.36), width * .88, localY(.25), width * .82, localY(.21), width * .79, localY(.14)], trunkWidth * .39, '#3e374b');
  branch(context, [width * .858, localY(.32), width * .82, localY(.34), width * .725, localY(.24), width * .667, localY(.24)], trunkWidth * .35, '#3e374b');
  branch(context, [width * .915, localY(.46), width * .974, localY(.45), width * .996, localY(.49), width * 1.07, localY(.43)], trunkWidth * .29, '#3e374b');
  branch(context, [width * .872, localY(.30), width * .886, localY(.23), width * .985, localY(.19), width * 1.027, localY(.15)], trunkWidth * .3, '#3e374b');
  branch(context, [trunkX - width * .007, trunkY - height * .02, width * .932, height * .741, width * .942, localY(.55), width * .909, localY(.45)], trunkWidth * .13, '#bd849147');

  const clusters = [
    [.730, crownY - .052, .095, .075],
    [.815, crownY - .12, .105, .077],
    [.923, crownY - .139, .105, .068],
    [1.015, crownY - .075, .13, .09],
    [.854, crownY - .007, .12, .07],
    [.706, crownY + .013, .073, .053],
    [.994, crownY + .074, .11, .069],
    [.917, crownY + .023, .09, .075],
    [1.064, crownY + .13, .095, .047],
  ];
  clusters.forEach(([clusterX, clusterY, radiusX, radiusY], clusterIndex) => {
    const clusterCount = Math.round((left ? 150 : 250) * (radiusX / .1));
    const centerX = width * clusterX;
    const centerY = height * clusterY;
    glow(context, centerX, centerY, width * radiusX * .92, '#e3adc315');
    for (let index = 0; index < clusterCount; index++) {
      const angle = random() * Math.PI * 2;
      const distance = Math.sqrt(random());
      const blossomX = centerX + Math.cos(angle) * distance * width * radiusX;
      const blossomY = centerY + Math.sin(angle) * distance * height * radiusY;
      const blossomSize = width * (.0016 + random() * .0056) * (left ? .8 : 1);
      const light = (1 - Math.sin(angle) * .35 - distance * .23) * random();
      const colors = light > .66 ? ['#eec0d0e6', '#f6ccd9db', '#e8b8d2df'] : light > .32 ? ['#c697b9d9', '#bc93b4df', '#d5a4c1db'] : ['#846b99d9', '#a27da8d9', '#95729bd9'];
      ellipse(context, blossomX, blossomY, blossomSize * (1.2 + random() * .4), blossomSize * (.7 + random() * .5), colors[(index + clusterIndex) % 3], random() * 2);
    }
  });

  for (let index = 0; index < (left ? 95 : 300); index++) {
    const cluster = clusters[Math.floor(random() * clusters.length)];
    const angle = random() * Math.PI * 2;
    const distance = Math.sqrt(random());
    const flowerX = width * (cluster[0] + Math.cos(angle) * distance * cluster[2]);
    const flowerY = height * (cluster[1] + Math.sin(angle) * distance * cluster[3]);
    const flowerSize = width * (.0013 + random() * .0019);
    for (let petalIndex = 0; petalIndex < 5; petalIndex++) {
      const petalAngle = petalIndex * Math.PI * .4;
      ellipse(context, flowerX + Math.cos(petalAngle) * flowerSize * .8, flowerY + Math.sin(petalAngle) * flowerSize * .8, flowerSize, flowerSize * .56, index % 3 === 0 ? '#ffe1e8b3' : '#eac4db8c', petalAngle);
    }
    ellipse(context, flowerX, flowerY, flowerSize * .25, flowerSize * .25, '#f6dcbdc9');
  }

  for (let index = 0; index < 42; index++) {
    const petalX = width * (.66 + random() * .39);
    const petalY = height * (crownY + .07 + random() * .25);
    ellipse(context, petalX, petalY, width * (.0013 + random() * .0014), width * .001, '#f0c3db86', random() * Math.PI);
  }
  context.restore();
}

function drawForeground(context: CanvasRenderingContext2D, width: number, height: number, portrait: boolean): void {
  const random = seeded(2041);
  context.save();
  context.beginPath();
  context.moveTo(-width * .1, height * .9);
  context.bezierCurveTo(width * .025, height * .91, width * .08, height * .99, width * .26, height * 1.04);
  context.lineTo(-width * .1, height * 1.1);
  context.closePath();
  const nearBank = context.createLinearGradient(0, height * .9, 0, height);
  nearBank.addColorStop(0, '#20364c');
  nearBank.addColorStop(1, '#12273c');
  context.fillStyle = nearBank;
  context.fill();

  for (let index = 0; index < (portrait ? 36 : 65); index++) {
    const reedX = width * (random() * .17 - .025);
    const reedY = height * (.96 + random() * .1);
    const reedHeight = height * (.03 + random() * .105);
    const reedCurve = width * (random() - .5) * .04;
    context.strokeStyle = ['#304651', '#425364', '#51616d', '#182f40'][index % 4];
    context.lineWidth = width * (.0008 + random() * .0006);
    context.beginPath();
    context.moveTo(reedX, reedY);
    context.quadraticCurveTo(reedX + reedCurve * .2, reedY - reedHeight * .65, reedX + reedCurve, reedY - reedHeight);
    context.stroke();
    if (index % 4 === 0) {
      ellipse(context, reedX + reedCurve, reedY - reedHeight, width * .0011, height * .009, '#9f8fa281', -.15);
    }
    if (index % 5 === 0) {
      const bloomX = reedX + reedCurve;
      const bloomY = reedY - reedHeight;
      for (let petalIndex = 0; petalIndex < 5; petalIndex++) {
        const flowerAngle = petalIndex * Math.PI * .4;
        ellipse(context, bloomX + Math.cos(flowerAngle) * width * .0025, bloomY + Math.sin(flowerAngle) * height * .002, width * .0028, height * .0018, '#d7b3cf9c', flowerAngle);
      }
      ellipse(context, bloomX, bloomY, width * .0011, width * .0011, '#ebc6a8b0');
    }
  }

  for (let index = 0; index < 14; index++) {
    const lilyX = width * (.03 + random() * .31);
    const lilyY = height * (.89 + random() * .13);
    const lilyWidth = width * (.005 + random() * .009);
    ellipse(context, lilyX, lilyY + height * .001, lilyWidth * 1.35, height * .003, '#162c4766');
    ellipse(context, lilyX, lilyY, lilyWidth, lilyWidth * .19, '#46596280', -.12);
    context.strokeStyle = '#9b9caa27';
    context.lineWidth = width * .0006;
    context.beginPath();
    context.moveTo(lilyX - lilyWidth * .8, lilyY);
    context.lineTo(lilyX + lilyWidth * .8, lilyY - lilyWidth * .04);
    context.stroke();
    if (index % 5 === 0) {
      for (let petalIndex = 0; petalIndex < 5; petalIndex++) {
        const flowerAngle = Math.PI * (1 + petalIndex * .25);
        ellipse(context, lilyX + Math.cos(flowerAngle) * lilyWidth * .25, lilyY + Math.sin(flowerAngle) * lilyWidth * .25, lilyWidth * .35, lilyWidth * .11, '#dcadcda6', flowerAngle);
      }
    }
  }

  for (let index = 0; index < 40; index++) {
    const petalX = random() * width;
    const petalY = height * (.71 + random() * .28);
    ellipse(context, petalX, petalY, width * .0015, height * .0006, '#f2bfd35e', random() * .5);
    ellipse(context, petalX, petalY + height * .002, width * .004, height * .0004, '#dcb5d11a');
  }
  context.restore();
}

function paintScene(viewportWidth: number, viewportHeight: number): Drawing {
  const portrait = viewportHeight / viewportWidth > 1.06;
  const artScale = Math.min(1.5, 2100 / Math.max(viewportWidth, viewportHeight));
  const width = Math.max(1, Math.round(viewportWidth * artScale));
  const height = Math.max(1, Math.round(viewportHeight * artScale));
  const background = makeCanvas(width, height);
  const context = contextFor(background);
  const { moonX } = drawSky(context, width, height, portrait);
  const sky = makeCanvas(width, height);
  contextFor(sky).drawImage(background, 0, 0);
  const horizon = height * (portrait ? .565 : .551);
  drawWater(context, sky, width, height, horizon, moonX, portrait);

  const foreground = makeCanvas(width, height);
  const foregroundContext = contextFor(foreground);
  drawShore(foregroundContext, width, height, portrait);
  drawBlossomTree(foregroundContext, width, height, portrait);
  drawCottage(foregroundContext, width, height, portrait);
  drawBlossomTree(foregroundContext, width, height, portrait, true);
  drawForeground(foregroundContext, width, height, portrait);

  const vignette = foregroundContext.createRadialGradient(width * .49, height * .44, width * .12, width * .5, height * .45, Math.max(width, height) * .77);
  vignette.addColorStop(0, '#07142a00');
  vignette.addColorStop(.62, '#07142a00');
  vignette.addColorStop(1, '#07142a7d');
  foregroundContext.fillStyle = vignette;
  foregroundContext.fillRect(0, 0, width, height);

  const poster = makeCanvas(width, height);
  const posterContext = contextFor(poster);
  posterContext.drawImage(background, 0, 0);
  posterContext.drawImage(foreground, 0, 0);
  return { background, foreground, poster, horizon: 1 - horizon / height };
}

const vertexShader = `
  varying vec2 vUv;
  void main() {
    vUv = uv;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;

const waterFragmentShader = `
  uniform sampler2D uTexture;
  uniform float uTime;
  uniform float uAspect;
  uniform float uHorizon;
  uniform vec3 uRipples[4];
  varying vec2 vUv;
  void main() {
    vec2 sampleUv = vUv;
    float water = 1.0 - smoothstep(uHorizon - 0.015, uHorizon + 0.006, vUv.y);
    float depth = clamp((uHorizon - vUv.y) / uHorizon, 0.0, 1.0);
    sampleUv.x += water * (sin(vUv.y * 135.0 + uTime * 0.42) * 0.00055 + sin(vUv.y * 63.0 - uTime * 0.28) * 0.0008) * (0.3 + depth);
    sampleUv.y += water * sin(vUv.x * 33.0 + vUv.y * 88.0 + uTime * 0.3) * 0.00028;
    float rippleLight = 0.0;
    for (int index = 0; index < 4; index++) {
      float age = uTime - uRipples[index].z;
      if (age >= 0.0 && age < 6.0) {
        vec2 delta = vUv - uRipples[index].xy;
        delta.x *= uAspect;
        float distanceToRipple = length(delta);
        float ring = sin(distanceToRipple * 210.0 - age * 5.1) * exp(-abs(distanceToRipple - age * 0.038) * 39.0) * exp(-age * 0.65);
        sampleUv += normalize(delta + vec2(0.0001)) * ring * 0.0013 * water;
        rippleLight += ring * 0.018 * water;
      }
    }
    vec4 color = texture2D(uTexture, clamp(sampleUv, 0.001, 0.999));
    color.rgb += rippleLight;
    gl_FragColor = color;
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;

const particleVertexShader = `
  attribute float aSize;
  attribute float aPhase;
  attribute float aKind;
  uniform float uTime;
  uniform float uPixelRatio;
  uniform float uMotion;
  varying float vPhase;
  varying float vKind;
  varying float vOpacity;
  void main() {
    vec3 particle = position;
    float phase = aPhase;
    if (aKind < 0.5) {
      particle.y = mod(position.y + 1.0 - uTime * 0.018 * uMotion * (0.55 + phase * 0.12), 2.25) - 1.0;
      particle.x += sin(uTime * 0.22 * uMotion + phase * 6.0) * 0.035;
      particle.x -= uTime * 0.0015 * uMotion;
      vOpacity = 0.26 + sin(phase * 13.0) * 0.1;
    } else {
      particle.x += sin(uTime * 0.27 * uMotion + phase) * 0.006;
      particle.y += cos(uTime * 0.3 * uMotion + phase * 2.0) * 0.007;
      vOpacity = 0.25 + sin(uTime * 0.8 * uMotion + phase * 9.0) * 0.18;
    }
    vPhase = phase + uTime * 0.2 * uMotion;
    vKind = aKind;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(particle, 1.0);
    gl_PointSize = aSize * uPixelRatio;
  }
`;

const particleFragmentShader = `
  varying float vPhase;
  varying float vKind;
  varying float vOpacity;
  void main() {
    vec2 point = gl_PointCoord - 0.5;
    if (vKind < 0.5) {
      float rotation = vPhase * 3.0;
      point = mat2(cos(rotation), -sin(rotation), sin(rotation), cos(rotation)) * point;
      point.x *= 1.55;
      point.y *= 0.85;
      float shape = 1.0 - smoothstep(0.24, 0.46, length(point));
      float fold = smoothstep(-0.2, 0.3, point.x + point.y);
      gl_FragColor = vec4(mix(vec3(0.82, 0.60, 0.76), vec3(1.0, 0.86, 0.9), fold), shape * vOpacity);
    } else {
      float shape = exp(-dot(point, point) * 24.0);
      gl_FragColor = vec4(1.0, 0.87, 0.55, shape * vOpacity);
    }
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;

export function createScene(container: HTMLElement): () => void {
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const lowPower = (navigator.hardwareConcurrency ?? 8) <= 4 || (navigator as Navigator & { deviceMemory?: number }).deviceMemory === 2;
  let width = container.clientWidth || window.innerWidth;
  let height = container.clientHeight || window.innerHeight;
  let artwork = paintScene(width, height);
  const poster = artwork.poster;
  poster.className = 'scene-poster';
  poster.setAttribute('aria-hidden', 'true');
  Object.assign(poster.style, { position: 'absolute', inset: '0', width: '100%', height: '100%', objectFit: 'cover', pointerEvents: 'none' });
  container.append(poster);
  container.dataset.ready = 'true';

  let renderer: THREE.WebGLRenderer;
  try {
    renderer = new THREE.WebGLRenderer({ alpha: false, antialias: false, powerPreference: 'low-power', depth: false, stencil: false });
  } catch {
    let posterResizeTimer = 0;
    const resizePoster = () => {
      window.clearTimeout(posterResizeTimer);
      posterResizeTimer = window.setTimeout(() => {
        const nextWidth = container.clientWidth || window.innerWidth;
        const nextHeight = container.clientHeight || window.innerHeight;
        if (Math.abs(nextWidth - width) < 3 && Math.abs(nextHeight - height) < 80) return;
        width = nextWidth;
        height = nextHeight;
        const nextArtwork = paintScene(width, height);
        poster.width = nextArtwork.poster.width;
        poster.height = nextArtwork.poster.height;
        contextFor(poster).drawImage(nextArtwork.poster, 0, 0);
      }, 150);
    };
    window.addEventListener('resize', resizePoster, { passive: true });
    return () => {
      window.clearTimeout(posterResizeTimer);
      window.removeEventListener('resize', resizePoster);
      poster.remove();
    };
  }
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, lowPower ? 1 : 1.35));
  renderer.setSize(width, height, false);
  renderer.setViewport(0, 0, width, height);
  renderer.setScissorTest(false);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.setClearColor(palette.sky);
  renderer.domElement.setAttribute('aria-hidden', 'true');
  renderer.domElement.className = 'scene-canvas';
  Object.assign(renderer.domElement.style, { position: 'absolute', inset: '0', width: '100%', height: '100%', pointerEvents: 'none' });
  container.append(renderer.domElement);

  const scene = new THREE.Scene();
  const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, .1, 10);
  camera.position.z = 2;
  const geometry = new THREE.PlaneGeometry(2, 2);
  const createArtTexture = (canvas: HTMLCanvasElement) => {
    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.minFilter = THREE.LinearFilter;
    texture.generateMipmaps = false;
    return texture;
  };
  let backgroundTexture = createArtTexture(artwork.background);
  let foregroundTexture = createArtTexture(artwork.foreground);
  const ripples = Array.from({ length: 4 }, () => new THREE.Vector3(.5, .2, -100));
  const waterUniforms = {
    uTexture: { value: backgroundTexture },
    uTime: { value: 0 },
    uAspect: { value: width / height },
    uHorizon: { value: artwork.horizon },
    uRipples: { value: ripples },
  };
  const backgroundMaterial = new THREE.ShaderMaterial({ vertexShader, fragmentShader: waterFragmentShader, uniforms: waterUniforms, depthTest: false, depthWrite: false });
  const backgroundMesh = new THREE.Mesh(geometry, backgroundMaterial);
  backgroundMesh.scale.setScalar(1.017);
  scene.add(backgroundMesh);
  const foregroundMaterial = new THREE.MeshBasicMaterial({ map: foregroundTexture, transparent: true, depthTest: false, depthWrite: false });
  const foregroundMesh = new THREE.Mesh(geometry, foregroundMaterial);
  foregroundMesh.position.z = .1;
  foregroundMesh.scale.setScalar(1.024);
  foregroundMesh.renderOrder = 1;
  scene.add(foregroundMesh);

  const random = seeded(1925);
  const particleCount = lowPower ? 34 : 64;
  const particlePositions = new Float32Array(particleCount * 3);
  const particleSizes = new Float32Array(particleCount);
  const particlePhases = new Float32Array(particleCount);
  const particleKinds = new Float32Array(particleCount);
  for (let index = 0; index < particleCount; index++) {
    const firefly = index > particleCount * .66;
    particlePositions[index * 3] = firefly ? .28 + random() * .65 : -.95 + random() * 2;
    particlePositions[index * 3 + 1] = firefly ? -.61 + random() * .43 : -1 + random() * 2;
    particlePositions[index * 3 + 2] = .2;
    particleSizes[index] = firefly ? 4 + random() * 8 : 4 + random() * 5;
    particlePhases[index] = random() * Math.PI * 2;
    particleKinds[index] = firefly ? 1 : 0;
  }
  const particleGeometry = new THREE.BufferGeometry();
  particleGeometry.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
  particleGeometry.setAttribute('aSize', new THREE.BufferAttribute(particleSizes, 1));
  particleGeometry.setAttribute('aPhase', new THREE.BufferAttribute(particlePhases, 1));
  particleGeometry.setAttribute('aKind', new THREE.BufferAttribute(particleKinds, 1));
  const particleUniforms = { uTime: { value: 0 }, uPixelRatio: { value: renderer.getPixelRatio() }, uMotion: { value: reduceMotion.matches ? 0 : 1 } };
  const particleMaterial = new THREE.ShaderMaterial({ vertexShader: particleVertexShader, fragmentShader: particleFragmentShader, uniforms: particleUniforms, transparent: true, depthTest: false, depthWrite: false });
  const particles = new THREE.Points(particleGeometry, particleMaterial);
  particles.renderOrder = 2;
  particles.frustumCulled = false;
  scene.add(particles);

  let animation = 0;
  let disposed = false;
  let contextLost = false;
  let previousFrame = 0;
  let rippleIndex = 0;
  let pointerX = 0;
  let pointerY = 0;
  let scrollProgress = 0;
  let resizeTimer = 0;
  const originTime = performance.now();
  const frameInterval = lowPower ? 50 : 1000 / 30;

  const render = (timestamp: number) => {
    if (disposed || contextLost) return;
    const elapsed = (timestamp - originTime) / 1000;
    if (timestamp - previousFrame >= frameInterval - .5 || reduceMotion.matches) {
      previousFrame = timestamp;
      waterUniforms.uTime.value = reduceMotion.matches ? 0 : elapsed;
      particleUniforms.uTime.value = elapsed;
      const motion = reduceMotion.matches ? 0 : 1;
      backgroundMesh.position.x += (pointerX * .0018 * motion - backgroundMesh.position.x) * .04;
      foregroundMesh.position.x += (pointerX * .005 * motion - foregroundMesh.position.x) * .035;
      foregroundMesh.position.y += ((pointerY * .0025 + scrollProgress * .008) * motion - foregroundMesh.position.y) * .03;
      renderer.render(scene, camera);
    }
    if (!reduceMotion.matches && !document.hidden) animation = window.requestAnimationFrame(render);
  };

  const start = () => {
    window.cancelAnimationFrame(animation);
    particleUniforms.uMotion.value = reduceMotion.matches ? 0 : 1;
    render(performance.now());
  };
  const pointerMove = (event: PointerEvent) => {
    pointerX = event.clientX / width - .5;
    pointerY = event.clientY / height - .5;
  };
  const pointerDown = (event: PointerEvent) => {
    if (reduceMotion.matches || event.clientY < height * .56 || (event.target instanceof Element && event.target.closest('a, button, input, textarea, select, dialog, [role="button"]'))) return;
    if (document.querySelector('dialog[open]')) return;
    ripples[rippleIndex].set(event.clientX / width, 1 - event.clientY / height, (performance.now() - originTime) / 1000);
    rippleIndex = (rippleIndex + 1) % ripples.length;
  };
  const scroll = () => {
    scrollProgress = Math.min(1, window.scrollY / Math.max(1, document.documentElement.scrollHeight - height));
  };
  const resize = () => {
    window.clearTimeout(resizeTimer);
    resizeTimer = window.setTimeout(() => {
      if (disposed) return;
      const nextWidth = container.clientWidth || window.innerWidth;
      const nextHeight = container.clientHeight || window.innerHeight;
      if (Math.abs(nextWidth - width) < 3 && Math.abs(nextHeight - height) < 80) return;
      width = nextWidth;
      height = nextHeight;
      artwork = paintScene(width, height);
      poster.width = artwork.poster.width;
      poster.height = artwork.poster.height;
      contextFor(poster).drawImage(artwork.poster, 0, 0);
      const previousBackgroundTexture = backgroundTexture;
      const previousForegroundTexture = foregroundTexture;
      backgroundTexture = createArtTexture(artwork.background);
      foregroundTexture = createArtTexture(artwork.foreground);
      waterUniforms.uTexture.value = backgroundTexture;
      foregroundMaterial.map = foregroundTexture;
      foregroundMaterial.needsUpdate = true;
      previousBackgroundTexture.dispose();
      previousForegroundTexture.dispose();
      waterUniforms.uAspect.value = width / height;
      waterUniforms.uHorizon.value = artwork.horizon;
      renderer.setSize(width, height, false);
      renderer.setViewport(0, 0, width, height);
      renderer.setScissorTest(false);
      previousFrame = 0;
      start();
    }, 150);
  };
  const lost = (event: Event) => {
    event.preventDefault();
    contextLost = true;
    window.cancelAnimationFrame(animation);
    renderer.domElement.style.opacity = '0';
  };
  const restored = () => {
    contextLost = false;
    renderer.domElement.style.opacity = '1';
    start();
  };
  window.addEventListener('pointermove', pointerMove, { passive: true });
  window.addEventListener('pointerdown', pointerDown, { passive: true });
  window.addEventListener('scroll', scroll, { passive: true });
  window.addEventListener('resize', resize, { passive: true });
  document.addEventListener('visibilitychange', start);
  reduceMotion.addEventListener('change', start);
  renderer.domElement.addEventListener('webglcontextlost', lost);
  renderer.domElement.addEventListener('webglcontextrestored', restored);
  render(performance.now());

  return () => {
    disposed = true;
    window.cancelAnimationFrame(animation);
    window.clearTimeout(resizeTimer);
    window.removeEventListener('pointermove', pointerMove);
    window.removeEventListener('pointerdown', pointerDown);
    window.removeEventListener('scroll', scroll);
    window.removeEventListener('resize', resize);
    document.removeEventListener('visibilitychange', start);
    reduceMotion.removeEventListener('change', start);
    renderer.domElement.removeEventListener('webglcontextlost', lost);
    renderer.domElement.removeEventListener('webglcontextrestored', restored);
    backgroundTexture.dispose();
    foregroundTexture.dispose();
    geometry.dispose();
    backgroundMaterial.dispose();
    foregroundMaterial.dispose();
    particleGeometry.dispose();
    particleMaterial.dispose();
    renderer.dispose();
    renderer.domElement.remove();
    poster.remove();
  };
}

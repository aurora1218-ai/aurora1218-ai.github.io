export interface GalleryImage {
  src: string;
  srcSmall: string;
  width: number;
  height: number;
  alt: string;
  caption: string;
  title?: string;
}

const photo = (
  name: string,
  width: number,
  height: number,
  alt: string,
  caption: string,
  title: string,
): GalleryImage => ({
  src: `/images/${name}.webp`,
  srcSmall: `/images/${name}-small.webp`,
  width,
  height,
  alt,
  caption,
  title,
});

export const memories: GalleryImage[] = [
  photo(
    'cherry-blossoms', 1702, 1276,
    '浅粉樱花的枝条铺展在澄澈的蓝天下',
    '有些春天，因为分享而被记住。',
    '樱花开的时候',
  ),
  photo(
    'lake-and-sky', 5824, 4368,
    '蓝色天空和湖水在远处相接，水鸟停留在浅滩',
    '把见过的辽阔，也轻轻分给你。',
    '湖天一色',
  ),
  photo(
    'willow-light', 1702, 1276,
    '扬州荷花池公园里，金色阳光穿过柳枝落在草地上',
    '平常的日子，温柔的光。',
    '树影间的光',
  ),
  photo(
    'guangling-sunset', 1440, 1080,
    '广陵古城的屋檐下，夕阳将建筑染成金色',
    '让黄昏再慢一点。',
    '广陵的夕阳',
  ),
  photo(
    'jinji-lake', 1440, 1080,
    '苏州金鸡湖上方铺着蓝紫色晚霞，湖面倒映着天光',
    '一片晚霞，也值得认真收藏。',
    '湖畔晚霞',
  ),
  photo(
    'moon-above-clouds', 1080, 1440,
    '舷窗外，明亮的月光照在层叠的云海上',
    '抬头时，愿我们总能看见同一轮月亮。',
    '舷窗外的月亮',
  ),
];

export const worldMemories: GalleryImage[] = [
  photo(
    'minecraft-cherry-house', 1441, 1080,
    '我的世界中，樱花树旁的粉白色双层小屋',
    '一块一块，搭起属于我们的天地。',
    '樱花小屋',
  ),
  photo(
    'minecraft-cherry-balcony', 2557, 1447,
    '我的世界中，晓站在挂着青色灯笼的樱花小屋阳台上',
    '有你在，小屋就有了家的模样。',
    '晓与樱花小屋',
  ),
  photo(
    'minecraft-cherry-pavilion', 1833, 1280,
    '我的世界中，樱花山坡下的粉白色亭台',
    '把一点心意，放在樱花盛开的地方。',
    '樱花祭坛',
  ),
  photo(
    'minecraft-pink-figure', 1441, 1080,
    '我的世界中，用粉色方块搭建的大型角色手办',
    '一起做些可爱、认真又天马行空的事。',
    '小小的大手办',
  ),
  photo(
    'melody-house', 2559, 1486,
    '从高处看，草地上用粉白方块搭成的美乐蒂造型小屋',
    '把喜欢，搭成可爱的形状。',
    '美乐蒂小屋',
  ),
  photo(
    'flowers-in-another-world', 1260, 831,
    '方块世界里并肩生长的粉色花与蓝色花，画面写着另一个世界里的我们',
    '在另一个小小的世界，也一起盛开。',
    '世界里的我们',
  ),
  photo(
    'playing-together', 1121, 665,
    '王者荣耀里一起组队后的好友协作画面',
    '一起出发，就很开心。',
    '一起组队',
  ),
];

export const extraMemories: GalleryImage[] = [
  photo(
    'cherry-night', 1252, 704,
    '樱花夜景插画中，两个人并肩望向盛开的樱花树',
    '把喜欢的风景，留在这一页。',
    '爱与樱花',
  ),
  photo(
    'sea-of-light', 1741, 980,
    '夜色中，海面反射出一片温暖的金色光芒',
    '愿温柔的光，一直照进生活。',
    '光海',
  ),
  photo(
    'sunrise-city', 2559, 1427,
    '日出插画中，金色阳光照亮远处的城市',
    '明天，还有新的光。',
    '日出',
  ),
  photo(
    'moonlit-dream', 2228, 1054,
    '蓝色月夜插画中，少女坐在辽阔的夜色下',
    '给天马行空，留一片星空。',
    '月下的梦',
  ),
  photo(
    'poem-page', 1280, 1790,
    '一页印着诗歌与线描插图的书',
    '有些话，读着读着就想与你分享。',
    '诗歌的一页',
  ),
  photo(
    'sun-bird', 1280, 1280,
    '黑暗中，一轮明亮的太阳神鸟图案',
    '收藏一束，特别的光。',
    '太阳神鸟',
  ),
  photo(
    'illustrated-girl', 928, 1232,
    '暖金色插画中，女孩坐在咖啡馆的窗边',
    '愿每一天，都有柔软的片刻。',
    '暖色的片刻',
  ),
];


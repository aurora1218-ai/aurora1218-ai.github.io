import { readdir, readFile, writeFile, mkdir, copyFile, unlink } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const project = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const build = path.join(project, 'dist');
const output = path.join(project, '.publish');
const seen = new Set();
await mkdir(output, { recursive: true });
await mkdir(path.join(project, '.tools'), { recursive: true });

async function collect(directory) {
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const source = path.join(directory, entry.name);
    if (entry.isDirectory()) {
      await collect(source);
      continue;
    }
    if (seen.has(entry.name)) throw new Error(`Duplicate deployment filename: ${entry.name}`);
    seen.add(entry.name);
    const target = path.join(output, entry.name);
    if (/\.(html|css|js)$/.test(entry.name)) {
      const content = (await readFile(source, 'utf8')).replaceAll('/images/', '/').replaceAll('/fonts/', '/').replaceAll('/assets/', '/');
      await writeFile(target, content);
    } else {
      await copyFile(source, target);
    }
  }
}

await collect(build);
for (const entry of await readdir(output, { withFileTypes: true })) {
  if (entry.isFile() && /^index-[\w-]+\.(js|css)$/.test(entry.name) && !seen.has(entry.name)) {
    await unlink(path.join(output, entry.name));
  }
}
await copyFile(path.join(project, 'README.md'), path.join(output, 'README.md'));
await writeFile(path.join(project, '.tools', 'publish-files.json'), JSON.stringify([...seen, 'README.md'].map((filename) => path.join(output, filename)), null, 2));
console.log(`${seen.size + 1} static files prepared in ${output}`);

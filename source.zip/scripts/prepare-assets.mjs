import { readdir, mkdir } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import sharp from 'sharp';

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const inputDirectory = process.argv[2] ?? path.join(os.homedir(), 'Desktop', 'xiao_imgs');
const outputDirectory = path.join(projectRoot, 'public', 'images');

const imageNames = {
  '爱与樱花.jpg': 'cherry-night',
  '光海.jpg': 'sea-of-light',
  '湖天一色.jpg': 'lake-and-sky',
  '美乐蒂小屋.png': 'melody-house',
  '日出.png': 'sunrise-city',
  '少女.png': 'moonlit-dream',
  '诗歌.jpg': 'poem-page',
  '世界里的我们.jpg': 'flowers-in-another-world',
  '苏州-金鸡湖.jpg': 'jinji-lake',
  '太阳神鸟.jpg': 'sun-bird',
  '王者荣耀-一起组队.jpg': 'playing-together',
  '我的世界-大手办.jpg': 'minecraft-pink-figure',
  '我的世界-晓与樱花小屋.png': 'minecraft-cherry-balcony',
  '我的世界-樱花祭坛.jpg': 'minecraft-cherry-pavilion',
  '我的世界-樱花小屋.jpg': 'minecraft-cherry-house',
  '舷窗外的明月.jpg': 'moon-above-clouds',
  '扬州-广陵古城.jpg': 'guangling-sunset',
  '扬州-荷花池公园.jpg': 'willow-light',
  '樱花.jpg': 'cherry-blossoms',
  'AI绘图-女孩.jpg': 'illustrated-girl',
};

const requestedNames = process.argv.slice(3);
const selectedNames = new Set(requestedNames.length > 0 ? requestedNames : Object.values(imageNames));
for (const name of selectedNames) {
  if (!Object.values(imageNames).includes(name)) {
    throw new Error(`Unknown image name: ${name}`);
  }
}

await mkdir(outputDirectory, { recursive: true });
const inputFiles = new Set(await readdir(inputDirectory));
let totalBytes = 0;

for (const [inputName, outputName] of Object.entries(imageNames)) {
  if (!selectedNames.has(outputName)) {
    continue;
  }

  if (!inputFiles.has(inputName)) {
    throw new Error(`Missing source image: ${inputName}`);
  }

  const inputPath = path.join(inputDirectory, inputName);
  const sourceMetadata = await sharp(inputPath).metadata();
  const variants = [
    { suffix: '', width: 1800, quality: 86 },
    { suffix: '-small', width: 800, quality: 80 },
  ];

  for (const variant of variants) {
    const result = await sharp(inputPath)
      .rotate()
      .resize({ width: variant.width, withoutEnlargement: true })
      .webp({ quality: variant.quality, effort: 6 })
      .toFile(path.join(outputDirectory, `${outputName}${variant.suffix}.webp`));

    totalBytes += result.size;
    process.stdout.write(`${outputName}${variant.suffix}.webp ${result.width}x${result.height} ${Math.round(result.size / 1024)} KB\n`);
  }

  if (!sourceMetadata.width || !sourceMetadata.height) {
    throw new Error(`Could not read dimensions: ${inputName}`);
  }
}

process.stdout.write(`Prepared ${selectedNames.size} images with two sizes each, ${(totalBytes / 1024 / 1024).toFixed(2)} MB total.\n`);
